export default function IndividualData({individualExcelData}){
    return (
        <>
        <th>{individualExcelData.Id}</th>
        <th>{individualExcelData.Name}</th>
        <th>{individualExcelData.Number}</th>
        <th>{individualExcelData.Etc}</th>
        </>
    )

}